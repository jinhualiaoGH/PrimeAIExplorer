# PrimeAIExplorer v0.5.0 Observatory Report

- Experiment: `EXP-000001`
- Pilot: `pilot_002`
- Model: `GPT-5.6 Thinking`
- Completed: **1 / 5**
- Accuracy: **0.00%**
- Brier: **0.032400**
- ECE: **0.180000**

## Prediction bias

| Gap | Predicted | Truth | Bias |
|---:|---:|---:|---:|
| 4 | 1 | 0 | 1 |
| 6 | 0 | 1 | -1 |

## Timing

- Recorded response durations: **0**
- Mean response seconds: **n/a**
- Median response seconds: **n/a**
- Timestamped responses: **0**
- Mean collection interval: **n/a seconds**
