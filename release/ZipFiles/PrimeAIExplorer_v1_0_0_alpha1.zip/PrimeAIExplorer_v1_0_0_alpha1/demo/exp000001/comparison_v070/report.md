# PrimeAIExplorer v0.7.0 Comparative Observatory

Analyses compared: **2**

## Model and pilot comparison

| Label | Records | Accuracy | Brier | ECE | Mean |error| | Switch rate | Favorite |
|---|---:|---:|---:|---:|---:|---:|---:|
| GPT-5.6 Thinking | 1 | 0.00% | 0.0324 | 0.1800 | 2.00 | 0.00% | 4 |
| Comparison Model | 1 | 0.00% | 0.0324 | 0.1800 | 2.00 | 0.00% | 4 |

## Best observed values

- **accuracy**: GPT-5.6 Thinking (0; higher is better)
- **brier_score**: GPT-5.6 Thinking (0.0324; lower is better)
- **ece**: GPT-5.6 Thinking (0.18; lower is better)
- **mean_absolute_error**: GPT-5.6 Thinking (2; lower is better)
