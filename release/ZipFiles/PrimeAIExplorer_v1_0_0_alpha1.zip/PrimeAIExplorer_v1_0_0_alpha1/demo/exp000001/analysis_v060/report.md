# PrimeAIExplorer v0.6.0 Observatory Report

- Experiment: `EXP-000001`
- Pilot: `pilot_002`
- Model: `GPT-5.6 Thinking`
- Completed: **2 / 5**
- Accuracy: **50.00%**
- Brier: **0.096200**
- ECE: **0.290000**

## Prediction bias

| Gap | Predicted | Truth | Bias |
|---:|---:|---:|---:|
| 4 | 1 | 0 | 1 |
| 6 | 1 | 2 | -1 |

## Timing

- Recorded response durations: **0**
- Mean response seconds: **n/a**
- Median response seconds: **n/a**
- Timestamped responses: **1**
- Mean collection interval: **n/a seconds**
